import { useState } from "react";

export default function Cliente({ usuario, sair }) {

    const [pagina, setPagina] = useState("inicio");

    return (

        <main className="painel">

            <header>

                <div>
                    <h1>PULLO</h1>
                    <p>Olá, {usuario?.nome}</p>
                </div>

                <button onClick={sair}>
                    Sair
                </button>

            </header>

            <nav className="menu">

                <button onClick={() => setPagina("inicio")}>
                    Início
                </button>

                <button onClick={() => setPagina("pedido")}>
                    Novo pedido
                </button>

                <button onClick={() => setPagina("historico")}>
                    Histórico
                </button>

                <button onClick={() => setPagina("perfil")}>
                    Meu perfil
                </button>

                <button onClick={() => setPagina("acompanhar")}>
                    Acompanhar
                </button>

            </nav>

            <section className="conteudo">

                {pagina === "inicio" && (

                    <>
                        <h2>Área do Cliente</h2>

                        <div className="cards">

                            <div>
                                <h3>Pedidos ativos</h3>
                                <h2>0</h2>
                            </div>

                            <div>
                                <h3>Pedidos concluídos</h3>
                                <h2>0</h2>
                            </div>

                            <div>
                                <h3>Entregas</h3>
                                <h2>0</h2>
                            </div>

                        </div>
                    </>
                )}

                {pagina === "pedido" && (
                    <NovoPedido />
                )}

                {pagina === "historico" && (

                    <>
                        <h2>Histórico de pedidos</h2>
                        <p>Nenhum pedido cadastrado.</p>
                    </>
                )}

                {pagina === "perfil" && (

                    <>
                        <h2>Meu perfil</h2>

                        <input
                            defaultValue={usuario?.nome}
                            placeholder="Nome"
                        />

                        <input
                            defaultValue={usuario?.email}
                            placeholder="E-mail"
                        />

                        <input
                            placeholder="Telefone"
                        />

                        <button>
                            Salvar alterações
                        </button>
                    </>
                )}

                {pagina === "acompanhar" && (

                    <>
                        <h2>Acompanhar pedido</h2>

                        <div className="status">

                            <p>🟡 Pedido recebido</p>

                            <p>
                                🟠 Entregador a caminho do supermercado
                            </p>

                            <p>🔵 Pedido retirado</p>

                            <p>🟢 A caminho do cliente</p>

                            <p>✅ Entrega concluída</p>

                        </div>
                    </>
                )}

            </section>

        </main>
    );
}

function NovoPedido() {

    function cadastrar() {
        alert("Pedido cadastrado!");
    }

    return (

        <>
            <h2>Novo pedido</h2>

            <input
                placeholder="Supermercado"
            />

            <input
                placeholder="Número do pedido"
            />

            <input
                placeholder="Endereço de entrega"
            />

            <input
                placeholder="Horário"
            />

            <textarea
                placeholder="Observações"
            />

            <button onClick={cadastrar}>
                Cadastrar pedido
            </button>
        </>
    );
}