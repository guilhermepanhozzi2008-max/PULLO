import { useState } from "react";

export default function Cadastro({ voltar, confirmar }) {

    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [telefone, setTelefone] = useState("");
    const [senha, setSenha] = useState("");
    const [tipo, setTipo] = useState("CLIENTE");

    function cadastrar(e) {

        e.preventDefault();

        if (!nome || !email || !senha) {
            alert("Preencha os campos obrigatórios.");
            return;
        }

        alert("Código de confirmação enviado para o e-mail.");

        confirmar();
    }

    return (
        <main className="tela">

            <div className="caixa">

                <h1>Criar conta</h1>

                <form onSubmit={cadastrar}>

                    <input
                        placeholder="Nome completo"
                        value={nome}
                        onChange={(e) => setNome(e.target.value)}
                    />

                    <input
                        type="email"
                        placeholder="E-mail"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />

                    <input
                        placeholder="Telefone"
                        value={telefone}
                        onChange={(e) => setTelefone(e.target.value)}
                    />

                    <input
                        type="password"
                        placeholder="Senha"
                        value={senha}
                        onChange={(e) => setSenha(e.target.value)}
                    />

                    <select
                        value={tipo}
                        onChange={(e) => setTipo(e.target.value)}
                    >
                        <option value="CLIENTE">
                            Cliente
                        </option>

                        <option value="ENTREGADOR">
                            Entregador
                        </option>
                    </select>

                    <button type="submit">
                        Finalizar cadastro
                    </button>

                </form>

                <button
                    className="link"
                    onClick={voltar}
                >
                    Voltar para login
                </button>

            </div>

        </main>
    );
}