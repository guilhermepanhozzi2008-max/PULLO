import { useState } from "react";

export default function RecuperarSenha({ voltar }) {

    const [email, setEmail] = useState("");
    const [novaSenha, setNovaSenha] = useState("");
    const [confirmar, setConfirmar] = useState("");
    const [etapa, setEtapa] = useState(1);

    function continuar(e) {

        e.preventDefault();

        if (!email) {
            alert("Digite seu e-mail.");
            return;
        }

        setEtapa(2);
    }

    function alterarSenha(e) {

        e.preventDefault();

        if (novaSenha !== confirmar) {
            alert("As senhas não são iguais.");
            return;
        }

        if (novaSenha.length < 6) {
            alert("A senha deve possuir pelo menos 6 caracteres.");
            return;
        }

        alert("Senha alterada com sucesso.");

        voltar();
    }

    return (
        <main className="tela">

            <div className="caixa">

                <h1>Recuperar senha</h1>

                {etapa === 1 && (

                    <form onSubmit={continuar}>

                        <input
                            type="email"
                            placeholder="Digite seu e-mail"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                        />

                        <button>
                            Continuar
                        </button>

                    </form>

                )}

                {etapa === 2 && (

                    <form onSubmit={alterarSenha}>

                        <input
                            type="password"
                            placeholder="Nova senha"
                            value={novaSenha}
                            onChange={(e) =>
                                setNovaSenha(e.target.value)
                            }
                        />

                        <input
                            type="password"
                            placeholder="Confirmar nova senha"
                            value={confirmar}
                            onChange={(e) =>
                                setConfirmar(e.target.value)
                            }
                        />

                        <button>
                            Alterar senha
                        </button>

                    </form>

                )}

                <button
                    className="link"
                    onClick={voltar}
                >
                    Voltar
                </button>

            </div>

        </main>
    );
}