import { useState } from "react";

export default function Confirmacao({ voltar }) {

    const [codigo, setCodigo] = useState("");

    function confirmar(e) {

        e.preventDefault();

        if (codigo !== "123456") {
            alert("Código incorreto.");
            return;
        }

        alert("Conta confirmada com sucesso!");

        voltar();
    }

    return (
        <main className="tela">

            <div className="caixa">

                <h1>Confirmar conta</h1>

                <p>
                    Digite o código enviado para seu e-mail.
                </p>

                <form onSubmit={confirmar}>

                    <input
                        placeholder="Código de confirmação"
                        value={codigo}
                        onChange={(e) => setCodigo(e.target.value)}
                    />

                    <button type="submit">
                        Confirmar
                    </button>

                </form>

            </div>

        </main>
    );
}