import { useState } from "react";

export default function Entregador({ usuario, sair }) {

    const [status, setStatus] = useState("disponivel");

    return (

        <main className="painel">

            <header>

                <div>
                    <h1>PULLO Entregador</h1>
                    <p>Olá, {usuario?.nome}</p>
                </div>

                <button onClick={sair}>
                    Sair
                </button>

            </header>

            <section className="conteudo">

                <h2>Entrega disponível</h2>

                <div className="pedido-card">

                    <h3>Pedido #001</h3>

                    <p>
                        Supermercado: Mercado PULLO
                    </p>

                    <p>
                        Endereço: Rua Principal, 100
                    </p>

                    {status === "disponivel" && (

                        <button
                            onClick={() => setStatus("aceito")}
                        >
                            Aceitar entrega
                        </button>

                    )}

                    {status === "aceito" && (

                        <>
                            <p>Status: Entrega aceita</p>

                            <button
                                onClick={() => setStatus("retirada")}
                            >
                                Confirmar retirada
                            </button>
                        </>

                    )}

                    {status === "retirada" && (

                        <>
                            <p>Status: Pedido retirado</p>

                            <button
                                onClick={() => setStatus("entrega")}
                            >
                                Iniciar entrega
                            </button>
                        </>

                    )}

                    {status === "entrega" && (

                        <>
                            <p>Status: A caminho</p>

                            <button
                                onClick={() => setStatus("concluida")}
                            >
                                Finalizar entrega
                            </button>
                        </>

                    )}

                    {status === "concluida" && (

                        <p className="sucesso">
                            ✅ Entrega concluída!
                        </p>

                    )}

                </div>

            </section>

        </main>
    );
}