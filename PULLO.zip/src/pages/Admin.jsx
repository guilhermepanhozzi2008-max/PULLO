export default function Admin({ usuario, sair }) {

    return (

        <main className="painel">

            <header>

                <div>
                    <h1>PULLO Admin</h1>
                    <p>Olá, {usuario?.nome}</p>
                </div>

                <button onClick={sair}>
                    Sair
                </button>

            </header>

            <section className="conteudo">

                <h2>Painel administrativo</h2>

                <div className="cards">

                    <div>
                        <h3>Clientes</h3>
                        <h2>0</h2>
                    </div>

                    <div>
                        <h3>Entregadores</h3>
                        <h2>0</h2>
                    </div>

                    <div>
                        <h3>Pedidos</h3>
                        <h2>0</h2>
                    </div>

                    <div>
                        <h3>Entregas</h3>
                        <h2>0</h2>
                    </div>

                </div>

                <div className="acoes">

                    <button onClick={() => alert("Gerenciar usuários")}>
                        Gerenciar usuários
                    </button>

                    <button onClick={() => alert("Gerenciar pedidos")}>
                        Gerenciar pedidos
                    </button>

                    <button onClick={() => alert("Ver entregadores")}>
                        Ver entregadores
                    </button>

                    <button onClick={() => alert("Supermercados")}>
                        Supermercados
                    </button>

                </div>

            </section>

        </main>
    );
}