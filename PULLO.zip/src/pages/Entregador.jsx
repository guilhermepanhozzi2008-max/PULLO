export default function Entregador({ usuario, sair }) {
    return (
        <div>
            <h1>PULLO Entregador</h1>

            <h2>Olá, {usuario.nome}</h2>

            <section>
                <h3>Entregas disponíveis</h3>

                <div>
                    <p>Pedido: #001</p>
                    <p>Supermercado: Supermercado Central</p>
                    <p>Status: Aguardando</p>

                    <button>
                        Aceitar entrega
                    </button>
                </div>
            </section>

            <button>
                Minhas entregas
            </button>

            <button>
                Minha localização
            </button>

            <button onClick={sair}>
                Sair
            </button>
        </div>
    );
}