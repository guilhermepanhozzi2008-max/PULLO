import { useState } from "react";
import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Confirmacao from "./pages/Confirmacao";
import RecuperarSenha from "./pages/RecuperarSenha";
import Cliente from "./pages/Cliente";
import Entregador from "./pages/Entregador";
import Admin from "./pages/Admin";

export default function App() {

  const [pagina, setPagina] = useState("login");
  const [usuario, setUsuario] = useState(null);

  function entrar(dados) {

    setUsuario(dados);

    if (dados.tipo === "CLIENTE") {
      setPagina("cliente");
    }

    if (dados.tipo === "ENTREGADOR") {
      setPagina("entregador");
    }

    if (dados.tipo === "ADM") {
      setPagina("admin");
    }
  }

  function sair() {
    setUsuario(null);
    setPagina("login");
  }

  if (pagina === "cadastro") {
    return (
        <Cadastro
            voltar={() => setPagina("login")}
            confirmar={() => setPagina("confirmacao")}
        />
    );
  }

  if (pagina === "confirmacao") {
    return (
        <Confirmacao
            voltar={() => setPagina("login")}
        />
    );
  }

  if (pagina === "recuperar") {
    return (
        <RecuperarSenha
            voltar={() => setPagina("login")}
        />
    );
  }

  if (pagina === "cliente") {
    return (
        <Cliente
            usuario={usuario}
            sair={sair}
        />
    );
  }

  if (pagina === "entregador") {
    return (
        <Entregador
            usuario={usuario}
            sair={sair}
        />
    );
  }

  if (pagina === "admin") {
    return (
        <Admin
            usuario={usuario}
            sair={sair}
        />
    );
  }

  return (
      <Login
          entrar={entrar}
          cadastrar={() => setPagina("cadastro")}
          recuperar={() => setPagina("recuperar")}
      />
  );
}