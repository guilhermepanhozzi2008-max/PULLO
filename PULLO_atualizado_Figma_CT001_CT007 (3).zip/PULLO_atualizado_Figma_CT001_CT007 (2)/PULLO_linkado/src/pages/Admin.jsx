import Header from "../components/Header/Header";
import CardGrid from "../components/CardGrid/CardGrid";
import Card from "../components/Card/Card";
import Button from "../components/Button/Button";
import styles from "./Admin.module.css";

export default function Admin({ usuario, sair }) {

    return (
        <main className={styles.painel}>

            <Header titulo="PULLO Admin" usuario={usuario} sair={sair} />

            <section className={styles.conteudo}>

                <h2>Painel administrativo</h2>

                <CardGrid>
                    <Card titulo="Clientes" valor={0} />
                    <Card titulo="Entregadores" valor={0} />
                    <Card titulo="Pedidos" valor={0} />
                    <Card titulo="Entregas" valor={0} />
                </CardGrid>

                <div className={styles.acoes}>

                    <Button onClick={() => alert("Gerenciar usuários")}>
                        Gerenciar usuários
                    </Button>

                    <Button onClick={() => alert("Gerenciar pedidos")}>
                        Gerenciar pedidos
                    </Button>

                    <Button onClick={() => alert("Ver entregadores")}>
                        Ver entregadores
                    </Button>

                    <Button onClick={() => alert("Supermercados")}>
                        Supermercados
                    </Button>

                </div>

            </section>

        </main>
    );
}
