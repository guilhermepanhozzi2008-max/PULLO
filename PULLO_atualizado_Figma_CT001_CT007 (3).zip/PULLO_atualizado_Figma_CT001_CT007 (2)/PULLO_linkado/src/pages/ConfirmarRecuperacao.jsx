import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./ConfirmarRecuperacao.module.css";

export default function ConfirmarRecuperacao() {

    const navigate = useNavigate();

    const [codigo, setCodigo] = useState("");

    const email =
        localStorage.getItem(
            "email_recuperacao"
        );

    async function confirmar(e) {

        e.preventDefault();

        if (!codigo) {

            alert(
                "Digite o código recebido."
            );

            return;
        }

        if (!email) {

            alert(
                "E-mail não encontrado."
            );

            navigate("/recuperar-senha");

            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/confirmar_codigo_recuperacao",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        codigo: codigo
                    })
                }
            );

            const dados =
                await resposta.json();

            if (!resposta.ok) {

                alert(
                    dados.error ||
                    "Código inválido."
                );

                return;
            }

            navigate(
                "/nova-senha"
            );

        } catch (erro) {

            console.log(
                "Erro:",
                erro
            );

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Confirmar código">

            <p>
                Enviamos um novo código para:
            </p>

            <p>
                <strong>
                    {email}
                </strong>
            </p>

            <form
                className={styles.formulario}
                onSubmit={confirmar}
            >

                <Input
                    placeholder="Digite o código"
                    value={codigo}
                    onChange={(e) =>
                        setCodigo(e.target.value)
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Confirmar código
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/recuperar-senha")
                }
            >
                Voltar
            </Button>

        </AuthBox>
    );
}