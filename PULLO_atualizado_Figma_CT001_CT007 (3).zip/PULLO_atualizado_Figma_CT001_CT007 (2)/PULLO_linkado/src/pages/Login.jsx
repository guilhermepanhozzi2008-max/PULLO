import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./Login.module.css";

export default function Login({ entrar }) {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");
    const [carregando, setCarregando] = useState(false);
    const [erro, setErro] = useState("");

    async function fazerLogin(e) {
        e.preventDefault();
        setErro("");

        if (!email || !senha) {
            setErro("Digite seu e-mail e sua senha.");
            return;
        }

        setCarregando(true);

        try {
            const resposta = await fetch("http://localhost:5000/api/login", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, senha })
            });

            const dados = await resposta.json();

            if (!resposta.ok) {
                setErro(dados.error || "Erro ao realizar login.");
                return;
            }

            const usuario = dados.usuario;
            entrar(usuario);

            if (usuario.tipo === "CLIENTE") navigate("/cliente");
            else if (usuario.tipo === "ENTREGADOR") navigate("/entregador");
            else if (usuario.tipo === "ADM") navigate("/admin");
            else setErro("Tipo de usuário inválido.");
        } catch (erro) {
            console.log(erro);
            setErro("Não foi possível conectar com o servidor.");
        } finally {
            setCarregando(false);
        }
    }

    return (
        <AuthBox titulo="Entrar">
            <form className={styles.formulario} onSubmit={fazerLogin}>
                <Input type="email" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
                <Input type="password" placeholder="Senha" value={senha} onChange={(e) => setSenha(e.target.value)} />

                {erro && <p className={styles.erro}>{erro}</p>}

                <Button type="submit" fullWidth disabled={carregando}>
                    {carregando ? "Entrando..." : "Entrar"}
                </Button>
            </form>

            <div className={styles.links}>
                <Button variant="link" fullWidth onClick={() => navigate("/cadastro")}>
                    Cadastre-se
                </Button>
                <Button variant="link" fullWidth onClick={() => navigate("/recuperar-senha")}>
                    Esqueceu a senha?
                </Button>
            </div>
        </AuthBox>
    );
}
