import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./RecuperarSenha.module.css";

export default function RecuperarSenha() {

    const navigate = useNavigate();

    const [email, setEmail] = useState("");

    async function continuar(e) {

        e.preventDefault();

        if (!email) {

            alert("Digite seu e-mail.");

            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/esqueceu_senha",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email
                    })
                }
            );

            const dados =
                await resposta.json();

            if (!resposta.ok) {

                alert(
                    dados.error ||
                    "Erro ao solicitar recuperação."
                );

                return;
            }

            localStorage.setItem(
                "email_recuperacao",
                email
            );

            navigate(
                "/confirmar-recuperacao"
            );

        } catch (erro) {

            console.log(
                "Erro:",
                erro
            );

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Recuperar senha">

            <form
                className={styles.formulario}
                onSubmit={continuar}
            >

                <Input
                    type="email"
                    placeholder="Digite seu e-mail"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Enviar código
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/login")
                }
            >
                Voltar
            </Button>

        </AuthBox>
    );
}