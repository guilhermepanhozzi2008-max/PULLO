import { useState } from "react";
import Header from "../components/Header/Header";
import PedidoCard from "../components/PedidoCard/PedidoCard";
import Button from "../components/Button/Button";
import styles from "./Entregador.module.css";

export default function Entregador({ usuario, sair }) {

    const [status, setStatus] = useState("disponivel");

    return (
        <main className={styles.painel}>

            <Header titulo="PULLO Entregador" usuario={usuario} sair={sair} />

            <section className={styles.conteudo}>

                <h2>Entrega disponível</h2>

                <PedidoCard
                    titulo="Pedido #001"
                    linhas={[
                        "Supermercado: Mercado PULLO",
                        "Endereço: Rua Principal, 100",
                    ]}
                >
                    {status === "disponivel" && (
                        <Button onClick={() => setStatus("aceito")}>
                            Aceitar entrega
                        </Button>
                    )}

                    {status === "aceito" && (
                        <>
                            <p>Status: Entrega aceita</p>

                            <Button onClick={() => setStatus("retirada")}>
                                Confirmar retirada
                            </Button>
                        </>
                    )}

                    {status === "retirada" && (
                        <>
                            <p>Status: Pedido retirado</p>

                            <Button onClick={() => setStatus("entrega")}>
                                Iniciar entrega
                            </Button>
                        </>
                    )}

                    {status === "entrega" && (
                        <>
                            <p>Status: A caminho</p>

                            <Button onClick={() => setStatus("concluida")}>
                                Finalizar entrega
                            </Button>
                        </>
                    )}

                    {status === "concluida" && (
                        <p className={styles.sucesso}>
                            ✅ Entrega concluída!
                        </p>
                    )}
                </PedidoCard>

            </section>

        </main>
    );
}
