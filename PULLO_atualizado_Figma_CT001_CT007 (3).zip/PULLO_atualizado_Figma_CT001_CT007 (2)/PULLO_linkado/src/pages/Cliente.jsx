import { useState } from "react";
import Header from "../components/Header/Header";
import Menu from "../components/Menu/Menu";
import CardGrid from "../components/CardGrid/CardGrid";
import Card from "../components/Card/Card";
import Input from "../components/Input/Input";
import TextArea from "../components/TextArea/TextArea";
import Button from "../components/Button/Button";
import StatusTracker from "../components/StatusTracker/StatusTracker";
import styles from "./Cliente.module.css";

const ITENS_MENU = [
    { chave: "inicio", rotulo: "Início" },
    { chave: "pedido", rotulo: "Novo pedido" },
    { chave: "historico", rotulo: "Histórico" },
    { chave: "perfil", rotulo: "Meu perfil" },
    { chave: "acompanhar", rotulo: "Acompanhar" },
];

export default function Cliente({ usuario, sair }) {

    const [pagina, setPagina] = useState("inicio");

    return (
        <main className={styles.painel}>

            <Header titulo="PULLO" usuario={usuario} sair={sair} />

            <Menu
                ativo={pagina}
                itens={ITENS_MENU.map((item) => ({
                    ...item,
                    onClick: () => setPagina(item.chave),
                }))}
            />

            <section className={styles.conteudo}>

                {pagina === "inicio" && (
                    <>
                        <h2>Área do Cliente</h2>

                        <CardGrid>
                            <Card titulo="Pedidos ativos" valor={0} />
                            <Card titulo="Pedidos concluídos" valor={0} />
                            <Card titulo="Entregas" valor={0} />
                        </CardGrid>
                    </>
                )}

                {pagina === "pedido" && (
                    <NovoPedido />
                )}

                {pagina === "historico" && (
                    <>
                        <h2>Histórico de pedidos</h2>
                        <p>Nenhum pedido cadastrado.</p>
                    </>
                )}

                {pagina === "perfil" && (
                    <>
                        <h2>Meu perfil</h2>

                        <Input
                            defaultValue={usuario?.nome}
                            placeholder="Nome"
                        />

                        <Input
                            defaultValue={usuario?.email}
                            placeholder="E-mail"
                        />

                        <Input
                            placeholder="Telefone"
                        />

                        <Button fullWidth>
                            Salvar alterações
                        </Button>
                    </>
                )}

                {pagina === "acompanhar" && (
                    <>
                        <h2>Acompanhar pedido</h2>

                        <StatusTracker
                            etapas={[
                                { emoji: "🟡", texto: "Pedido recebido" },
                                { emoji: "🟠", texto: "Entregador a caminho do supermercado" },
                                { emoji: "🔵", texto: "Pedido retirado" },
                                { emoji: "🟢", texto: "A caminho do cliente" },
                                { emoji: "✅", texto: "Entrega concluída" },
                            ]}
                        />
                    </>
                )}

            </section>

        </main>
    );
}

function NovoPedido() {

    function cadastrar() {
        alert("Pedido cadastrado!");
    }

    return (
        <>
            <h2>Novo pedido</h2>

            <Input placeholder="Supermercado" />
            <Input placeholder="Número do pedido" />
            <Input placeholder="Endereço de entrega" />
            <Input placeholder="Horário" />
            <TextArea placeholder="Observações" />

            <Button fullWidth onClick={cadastrar}>
                Cadastrar pedido
            </Button>
        </>
    );
}
