import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./NovaSenha.module.css";

export default function NovaSenha() {

    const navigate = useNavigate();

    const [novaSenha, setNovaSenha] = useState("");
    const [confirmar, setConfirmar] = useState("");
    const [erro, setErro] = useState("");

    const email = localStorage.getItem("email_recuperacao");

    async function alterarSenha(e) {

        e.preventDefault();

        setErro("");

        if (!email) {
            setErro("E-mail não encontrado.");
            return;
        }

        if (!novaSenha || !confirmar) {
            setErro("Preencha todos os campos.");
            return;
        }

        if (novaSenha !== confirmar) {
            setErro("As senhas não são iguais.");
            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/alterar_senha",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email: email,
                        nova_senha: novaSenha,
                        confirmar_senha: confirmar
                    })
                }
            );

            const dados = await resposta.json();

            if (!resposta.ok) {
                setErro(
                    dados.error || "Erro ao alterar senha."
                );
                return;
            }

            localStorage.removeItem(
                "email_recuperacao"
            );

            alert("Senha alterada com sucesso!");

            navigate("/login");

        } catch (erro) {

            console.log("ERRO REAL:", erro);

            setErro(
                "Não foi possível conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Nova senha">

            <form
                id="form-nova-senha"
                className={styles.formulario}
                onSubmit={alterarSenha}
            >

                <Input
                    id="nova-senha"
                    name="nova_senha"
                    className="input-nova-senha"
                    type="password"
                    placeholder="Nova senha"
                    value={novaSenha}
                    onChange={(e) =>
                        setNovaSenha(e.target.value)
                    }
                />

                <Input
                    id="confirmar-senha"
                    name="confirmar_senha"
                    className="input-confirmar-senha"
                    type="password"
                    placeholder="Confirmar nova senha"
                    value={confirmar}
                    onChange={(e) =>
                        setConfirmar(e.target.value)
                    }
                />

                {erro && (
                    <p
                        id="erro-nova-senha"
                        className={styles.erro}
                    >
                        {erro}
                    </p>
                )}

                <Button
                    id="botao-alterar-senha"
                    name="botao-alterar-senha"
                    className="botao-alterar-senha"
                    type="submit"
                    fullWidth
                >
                    Alterar senha
                </Button>

            </form>

            <Button
                id="botao-voltar"
                name="botao-voltar"
                className="botao-voltar"
                variant="link"
                fullWidth
                onClick={() => navigate("/login")}
            >
                Voltar
            </Button>

        </AuthBox>
    );
}