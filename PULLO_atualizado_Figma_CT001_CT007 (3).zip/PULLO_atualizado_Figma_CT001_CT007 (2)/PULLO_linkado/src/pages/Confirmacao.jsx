import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./Confirmacao.module.css";

export default function Confirmacao() {

    const navigate = useNavigate();

    const [codigo, setCodigo] = useState("");
    const [erro, setErro] = useState("");

    const email = localStorage.getItem("email_cadastro");

    async function confirmar(e) {

        e.preventDefault();

        setErro("");

        if (!email) {
            setErro(
                "E-mail não encontrado. Faça o cadastro novamente."
            );
            return;
        }

        if (!codigo) {
            setErro(
                "Digite o código recebido no e-mail."
            );
            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/verificar_codigo",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        codigo: codigo
                    })
                }
            );

            const dados = await resposta.json();

            if (resposta.ok) {

                localStorage.removeItem(
                    "email_cadastro"
                );

                navigate("/login", {
                    replace: true
                });

                return;
            }

            setErro(
                dados.error || "Código incorreto."
            );

        } catch {

            setErro(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Confirmar conta">

            <p
                id="texto-confirmacao"
                className={styles.texto}
            >
                Enviamos um código de confirmação para:

                <br />

                <strong>
                    {email || "seu e-mail"}
                </strong>
            </p>

            <form
                id="form-confirmacao"
                className={styles.formulario}
                onSubmit={confirmar}
            >

                <Input
                    id="codigo"
                    name="codigo"
                    className="input-codigo"
                    placeholder="Código recebido por e-mail"
                    value={codigo}
                    onChange={(e) =>
                        setCodigo(e.target.value)
                    }
                    autoFocus
                />

                {erro && (
                    <p
                        id="erro-confirmacao"
                        className={styles.erro}
                    >
                        {erro}
                    </p>
                )}

                <Button
                    id="botao-confirmar"
                    name="botao-confirmar"
                    className="botao-confirmar"
                    type="submit"
                    fullWidth
                >
                    Confirmar
                </Button>

                <Button
                    id="botao-voltar"
                    name="botao-voltar"
                    className="botao-voltar"
                    variant="link"
                    fullWidth
                    onClick={() =>
                        navigate("/cadastro")
                    }
                >
                    Voltar
                </Button>

            </form>

        </AuthBox>
    );
}