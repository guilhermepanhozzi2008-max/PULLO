import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Select from "../components/Select/Select";
import Button from "../components/Button/Button";

import styles from "./Cadastro.module.css";

export default function Cadastro() {

    const navigate = useNavigate();

    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [telefone, setTelefone] = useState("");
    const [senha, setSenha] = useState("");
    const [tipo, setTipo] = useState("CLIENTE");
    const [erro, setErro] = useState("");

    async function cadastrar(e) {

        e.preventDefault();

        setErro("");

        if (!nome || !email || !senha || !tipo) {
            setErro("Preencha os campos obrigatórios.");
            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/cadastro",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        nome,
                        email,
                        telefone,
                        senha,
                        tipo
                    })
                }
            );

            const dados = await resposta.json();

            if (!resposta.ok) {

                setErro(
                    dados.error ||
                    "Não foi possível criar a conta."
                );

                return;
            }

            localStorage.setItem(
                "email_cadastro",
                email
            );

            navigate("/confirmacao");

        } catch (erro) {

            console.log(erro);

            setErro(
                "Não foi possível conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Cadastro">

            <form
                id="form-cadastro"
                className={styles.formulario}
                onSubmit={cadastrar}
            >

                <Input
                    id="nome"
                    name="nome"
                    className="input-nome"
                    placeholder="Nome completo"
                    value={nome}
                    onChange={(e) =>
                        setNome(e.target.value)
                    }
                />

                <Input
                    id="email"
                    name="email"
                    className="input-email"
                    type="email"
                    placeholder="E-mail"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                />

                <Input
                    id="telefone"
                    name="telefone"
                    className="input-telefone"
                    placeholder="Telefone"
                    value={telefone}
                    onChange={(e) =>
                        setTelefone(e.target.value)
                    }
                />

                <Input
                    id="senha"
                    name="senha"
                    className="input-senha"
                    type="password"
                    placeholder="Senha"
                    value={senha}
                    onChange={(e) =>
                        setSenha(e.target.value)
                    }
                />

                <Select
                    id="tipo"
                    name="tipo"
                    className="select-tipo"
                    value={tipo}
                    onChange={(e) =>
                        setTipo(e.target.value)
                    }
                >
                    <option value="CLIENTE">
                        Cliente
                    </option>

                    <option value="ENTREGADOR">
                        Entregador
                    </option>
                </Select>

                {erro && (
                    <p
                        id="erro-cadastro"
                        className={styles.erro}
                    >
                        {erro}
                    </p>
                )}

                <Button
                    id="botao-cadastro"
                    name="botao-cadastro"
                    className="botao-cadastro"
                    type="submit"
                    fullWidth
                >
                    Cadastrar
                </Button>

            </form>

            <Button
                id="botao-voltar"
                name="botao-voltar"
                className="botao-voltar"
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/login")
                }
            >
                Voltar
            </Button>

        </AuthBox>
    );
}