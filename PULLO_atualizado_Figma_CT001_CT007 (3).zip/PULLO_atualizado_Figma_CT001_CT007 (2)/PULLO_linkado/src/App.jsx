import { useState } from "react";

import {
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Confirmacao from "./pages/Confirmacao";
import RecuperarSenha from "./pages/RecuperarSenha";
import ConfirmarRecuperacao from "./pages/ConfirmarRecuperacao";
import NovaSenha from "./pages/NovaSenha";

import Cliente from "./pages/Cliente";
import Entregador from "./pages/Entregador";
import Admin from "./pages/Admin";


function RotaProtegida({
                           usuario,
                           tipo,
                           children
                       }) {

    if (!usuario) {

        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    if (usuario.tipo !== tipo) {

        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    return children;
}


export default function App() {

    const [usuario, setUsuario] =
        useState(null);

    function sair() {
        setUsuario(null);
    }

    return (
        <Routes>

            {/* LOGIN */}

            <Route
                path="/login"
                element={
                    <Login
                        entrar={setUsuario}
                    />
                }
            />


            {/* CADASTRO */}

            <Route
                path="/cadastro"
                element={
                    <Cadastro />
                }
            />


            {/* CONFIRMAÇÃO DO CADASTRO */}

            <Route
                path="/confirmacao"
                element={
                    <Confirmacao />
                }
            />


            {/* RECUPERAR SENHA */}

            <Route
                path="/recuperar-senha"
                element={
                    <RecuperarSenha />
                }
            />


            {/* CONFIRMAR CÓDIGO DA RECUPERAÇÃO */}

            <Route
                path="/confirmar-recuperacao"
                element={
                    <ConfirmarRecuperacao />
                }
            />


            {/* NOVA SENHA */}

            <Route
                path="/nova-senha"
                element={
                    <NovaSenha />
                }
            />


            {/* CLIENTE */}

            <Route
                path="/cliente"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="CLIENTE"
                    >

                        <Cliente
                            usuario={usuario}
                            sair={sair}
                        />

                    </RotaProtegida>
                }
            />


            {/* ENTREGADOR */}

            <Route
                path="/entregador"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="ENTREGADOR"
                    >

                        <Entregador
                            usuario={usuario}
                            sair={sair}
                        />

                    </RotaProtegida>
                }
            />


            {/* ADMIN */}

            <Route
                path="/admin"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="ADM"
                    >

                        <Admin
                            usuario={usuario}
                            sair={sair}
                        />

                    </RotaProtegida>
                }
            />


            {/* PÁGINA INICIAL */}

            <Route
                path="/"
                element={
                    <Navigate
                        to="/login"
                        replace
                    />
                }
            />


            {/* ROTA NÃO ENCONTRADA */}

            <Route
                path="*"
                element={
                    <Navigate
                        to="/login"
                        replace
                    />
                }
            />

        </Routes>
    );
}