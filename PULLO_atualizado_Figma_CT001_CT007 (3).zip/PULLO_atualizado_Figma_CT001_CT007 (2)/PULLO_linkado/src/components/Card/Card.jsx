import styles from "./Card.module.css";

export default function Card({ titulo, valor }) {

    return (
        <div className={styles.card}>
            <h3>{titulo}</h3>
            <h2>{valor}</h2>
        </div>
    );
}
