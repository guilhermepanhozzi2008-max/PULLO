import styles from "./StatusTracker.module.css";

export default function StatusTracker({ etapas = [] }) {

    return (
        <div className={styles.status}>

            {etapas.map((etapa, indice) => (
                <p key={indice}>
                    {etapa.emoji} {etapa.texto}
                </p>
            ))}

        </div>
    );
}
