import styles from "./TextArea.module.css";

export default function TextArea({
    placeholder,
    value,
    defaultValue,
    onChange,
    name,
}) {

    return (
        <textarea
            name={name}
            placeholder={placeholder}
            value={value}
            defaultValue={defaultValue}
            onChange={onChange}
            className={styles.campo}
        />
    );
}
