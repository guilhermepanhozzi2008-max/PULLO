import styles from "./Button.module.css";

export default function Button({
                                   children,
                                   id,
                                   name,
                                   className,
                                   type = "button",
                                   onClick,
                                   fullWidth = false,
                                   variant = "primary",
                                   disabled = false
                               }) {
    return (
        <button
            id={id}
            name={name}
            type={type}
            onClick={onClick}
            disabled={disabled}
            className={`
                ${styles.button}
                ${styles[variant] || ""}
                ${fullWidth ? styles.fullWidth : ""}
                ${className || ""}
            `}
        >
            {children}
        </button>
    );
}