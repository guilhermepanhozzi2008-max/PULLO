import styles from "./AuthBox.module.css";
import logo from "../../assets/pullo-logo.png";

export default function AuthBox({ titulo, children }) {
    return (
        <main className={styles.tela}>
            <section className={styles.caixa}>
                <div className={styles.marca}>
                    <img src={logo} alt="PULLO" />
                </div>

                <h1>{titulo}</h1>

                {children}
            </section>
        </main>
    );
}
