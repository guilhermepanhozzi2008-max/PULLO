import Button from "../Button/Button";
import styles from "./Header.module.css";

export default function Header({ titulo, usuario, sair }) {

    return (
        <header className={styles.cabecalho}>

            <div>
                <h1>{titulo}</h1>
                <p>Olá, {usuario?.nome}</p>
            </div>

            <Button onClick={sair}>
                Sair
            </Button>

        </header>
    );
}
