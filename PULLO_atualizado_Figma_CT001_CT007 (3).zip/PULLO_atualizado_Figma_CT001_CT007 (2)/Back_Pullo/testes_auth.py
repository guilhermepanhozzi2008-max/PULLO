import unittest
from unittest.mock import patch

from werkzeug.security import generate_password_hash

from app import app


class TestAutenticacao(unittest.TestCase):

    def setUp(self):
        self.cliente = app.test_client()

    # CT001 - cadastro e login
    @patch("auth.enviar_email")
    @patch("app.models.criar_codigo")
    @patch("app.models.criar_usuario", return_value=100)
    @patch("app.models.buscar_usuario_por_email", return_value=None)
    def test_ct001_cadastro(self, buscar, criar, codigo, enviar):
        resposta = self.cliente.post("/api/cadastro", json={
            "nome": "Teste Cliente",
            "email": "teste_ct001@pullo.com",
            "telefone": "11999999999",
            "senha": "123456",
            "tipo": "CLIENTE"
        })
        self.assertEqual(resposta.status_code, 201)
        self.assertTrue(enviar.called)

    # CT001 - login funcionando
    @patch("app.models.zerar_tentativas")
    @patch("app.models.buscar_usuario_por_email")
    def test_ct001_login(self, buscar, zerar):
        buscar.return_value = (
            100, "Teste Cliente", "teste_ct001@pullo.com",
            generate_password_hash("123456"), "CLIENTE", 0, 0, 1
        )
        resposta = self.cliente.post("/api/login", json={
            "email": "teste_ct001@pullo.com",
            "senha": "123456"
        })
        self.assertEqual(resposta.status_code, 200)
        self.assertEqual(resposta.get_json()["usuario"]["tipo"], "CLIENTE")

    # CT002 - cada tipo de usuario
    @patch("app.models.zerar_tentativas")
    @patch("app.models.buscar_usuario_por_email")
    def test_ct002_tipos(self, buscar, zerar):
        senha = generate_password_hash("123456")

        for tipo in ["CLIENTE", "ENTREGADOR", "ADM"]:
            buscar.return_value = (
                1, "Usuario", f"{tipo.lower()}@teste.com",
                senha, tipo, 0, 0, 1
            )
            resposta = self.cliente.post("/api/login", json={
                "email": f"{tipo.lower()}@teste.com",
                "senha": "123456"
            })
            self.assertEqual(resposta.status_code, 200)
            self.assertEqual(resposta.get_json()["usuario"]["tipo"], tipo)

    # CT003 - tres erros bloqueiam
    @patch("app.models.buscar_usuario_por_email")
    @patch("app.models.registrar_tentativa_errada")
    def test_ct003_tres_erros(self, registrar, buscar):
        senha = generate_password_hash("123456")
        tentativas = [0]

        def usuario_atual(_):
            return (1, "Teste", "bloqueio@teste.com", senha,
                    "CLIENTE", tentativas[0], 0, 1)

        def registrar_fake(_id, atual):
            tentativas[0] = atual + 1

        buscar.side_effect = usuario_atual
        registrar.side_effect = registrar_fake

        for i in range(2):
            resposta = self.cliente.post("/api/login", json={
                "email": "bloqueio@teste.com",
                "senha": "errada"
            })
            self.assertEqual(resposta.status_code, 401)

        buscar.side_effect = lambda _: (
            1, "Teste", "bloqueio@teste.com", senha,
            "CLIENTE", 2, 0, 1
        )
        resposta = self.cliente.post("/api/login", json={
            "email": "bloqueio@teste.com",
            "senha": "errada"
        })
        self.assertEqual(resposta.status_code, 403)
        self.assertIn("bloqueado", resposta.get_json()["error"].lower())

    # CT004 - email duplicado
    @patch("app.models.buscar_usuario_por_email")
    def test_ct004_email_duplicado(self, buscar):
        buscar.return_value = (
            1, "Usuario", "duplicado@teste.com",
            generate_password_hash("123456"),
            "CLIENTE", 0, 0, 1
        )
        resposta = self.cliente.post("/api/cadastro", json={
            "nome": "Outro",
            "email": "duplicado@teste.com",
            "telefone": "11999999999",
            "senha": "123456",
            "tipo": "CLIENTE"
        })
        self.assertEqual(resposta.status_code, 400)
        self.assertEqual(resposta.get_json()["error"], "Email ja cadastrado")

    # CT005 - codigo enviado por email
    @patch("auth.enviar_email")
    @patch("app.models.criar_codigo")
    @patch("app.models.criar_usuario", return_value=101)
    @patch("app.models.buscar_usuario_por_email", return_value=None)
    def test_ct005_codigo(self, buscar, criar, codigo, enviar):
        resposta = self.cliente.post("/api/cadastro", json={
            "nome": "Codigo",
            "email": "codigo@teste.com",
            "telefone": "11999999999",
            "senha": "123456",
            "tipo": "CLIENTE"
        })
        self.assertEqual(resposta.status_code, 201)
        self.assertTrue(enviar.called)
        assunto = enviar.call_args.args[1]
        corpo = enviar.call_args.args[2]
        self.assertIn("Confirmacao", assunto)
        self.assertRegex(corpo, r"\b\d{6}\b")

    # CT006 - codigo errado e codigo certo
    @patch("app.models.confirmar_codigo")
    def test_ct006_codigo(self, confirmar):
        confirmar.return_value = False
        resposta = self.cliente.post("/api/verificar_codigo", json={
            "email": "codigo@teste.com",
            "codigo": "000000"
        })
        self.assertEqual(resposta.status_code, 401)

        confirmar.return_value = True
        resposta = self.cliente.post("/api/verificar_codigo", json={
            "email": "codigo@teste.com",
            "codigo": "123456"
        })
        self.assertEqual(resposta.status_code, 200)

    # CT007 - recuperacao exige codigo e impede senha antiga
    @patch("app.models.senha_ja_usada", return_value=True)
    @patch("app.models.recuperacao_confirmada", return_value=True)
    @patch("app.models.buscar_usuario_por_email")
    def test_ct007_senha_antiga(self, buscar, confirmado, usada):
        buscar.return_value = (
            1, "Usuario", "senha@teste.com",
            generate_password_hash("123456"),
            "CLIENTE", 0, 0, 1
        )
        resposta = self.cliente.post("/api/alterar_senha", json={
            "email": "senha@teste.com",
            "nova_senha": "123456",
            "confirmar_senha": "123456"
        })
        self.assertEqual(resposta.status_code, 400)
        self.assertIn("3 ultimas senhas", resposta.get_json()["error"].lower())


if __name__ == "__main__":
    unittest.main()
