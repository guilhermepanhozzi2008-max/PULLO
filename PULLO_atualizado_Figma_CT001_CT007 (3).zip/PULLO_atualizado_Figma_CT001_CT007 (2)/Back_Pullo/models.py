import fdb
from werkzeug.security import check_password_hash

import config


def conectar():
    return fdb.connect(
        dsn=config.FIREBIRD_DSN,
        user=config.FIREBIRD_USER,
        password=config.FIREBIRD_PASSWORD,
        charset="UTF8"
    )


# =========================================================
# BUSCAR USUARIO
# =========================================================

def buscar_usuario_por_email(email):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            ID_USUARIO,
            NOME,
            EMAIL,
            SENHA,
            TIPO,
            TENTATIVAS_LOGIN,
            BLOQUEADO,
            CONFIRMADO
        FROM USUARIOS
        WHERE EMAIL = ?
    """, (email,))

    usuario = cursor.fetchone()

    con.close()

    return usuario


def buscar_usuario_por_id(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            ID_USUARIO,
            NOME,
            EMAIL,
            TIPO,
            CONFIRMADO
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    usuario = cursor.fetchone()

    con.close()

    return usuario


# =========================================================
# CRIAR USUARIO
# =========================================================

def criar_usuario(nome, email, senha_hash, telefone, tipo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO USUARIOS (
            NOME,
            EMAIL,
            SENHA,
            TELEFONE,
            TIPO,
            TENTATIVAS_LOGIN,
            BLOQUEADO,
            CONFIRMADO
        )
        VALUES (?, ?, ?, ?, ?, 0, 0, 0)
        RETURNING ID_USUARIO
    """, (
        nome,
        email,
        senha_hash,
        telefone,
        tipo
    ))

    id_usuario = cursor.fetchone()[0]

    con.commit()
    con.close()

    return id_usuario


# =========================================================
# CRIAR CODIGO
# =========================================================

def criar_codigo(id_usuario, codigo, tipo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO CODIGOS (
            ID_USUARIO,
            CODIGO,
            TIPO,
            UTILIZADO,
            CONFIRMADO
        )
        VALUES (?, ?, ?, 0, 0)
    """, (
        id_usuario,
        codigo,
        tipo
    ))

    con.commit()
    con.close()


# =========================================================
# CONFIRMAR CADASTRO
# =========================================================

def confirmar_codigo(email, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            c.ID_CODIGO,
            u.ID_USUARIO
        FROM CODIGOS c
        JOIN USUARIOS u
            ON u.ID_USUARIO = c.ID_USUARIO
        WHERE u.EMAIL = ?
        AND c.CODIGO = ?
        AND c.TIPO = 'CONFIRMACAO'
        AND c.UTILIZADO = 0
    """, (
        email,
        codigo
    ))

    resultado = cursor.fetchone()

    if not resultado:
        con.close()
        return False

    id_codigo = resultado[0]
    id_usuario = resultado[1]

    cursor.execute("""
        UPDATE USUARIOS
        SET CONFIRMADO = 1
        WHERE ID_USUARIO = ?
    """, (
        id_usuario,
    ))

    cursor.execute("""
        UPDATE CODIGOS
        SET UTILIZADO = 1
        WHERE ID_CODIGO = ?
    """, (
        id_codigo,
    ))

    con.commit()
    con.close()

    return True


# =========================================================
# LOGIN
# =========================================================

def zerar_tentativas(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        UPDATE USUARIOS
        SET TENTATIVAS_LOGIN = 0
        WHERE ID_USUARIO = ?
    """, (
        id_usuario,
    ))

    con.commit()
    con.close()


def registrar_tentativa_errada(id_usuario, tentativas_atuais):
    novas_tentativas = tentativas_atuais + 1

    bloquear = 0

    if novas_tentativas >= config.MAX_TENTATIVAS_LOGIN:
        bloquear = 1

    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        UPDATE USUARIOS
        SET
            TENTATIVAS_LOGIN = ?,
            BLOQUEADO = ?
        WHERE ID_USUARIO = ?
    """, (
        novas_tentativas,
        bloquear,
        id_usuario
    ))

    con.commit()
    con.close()


# =========================================================
# CRIAR CODIGO DE RECUPERACAO
# =========================================================

def criar_codigo_recuperacao(id_usuario, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        INSERT INTO CODIGOS (
            ID_USUARIO,
            CODIGO,
            TIPO,
            UTILIZADO,
            CONFIRMADO
        )
        VALUES (?, ?, 'RECUPERACAO', 0, 0)
    """, (
        id_usuario,
        codigo
    ))

    con.commit()
    con.close()


# =========================================================
# CONFIRMAR CODIGO DE RECUPERACAO
# =========================================================

def confirmar_codigo_recuperacao(email, codigo):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT
            c.ID_CODIGO
        FROM CODIGOS c
        JOIN USUARIOS u
            ON u.ID_USUARIO = c.ID_USUARIO
        WHERE u.EMAIL = ?
        AND c.CODIGO = ?
        AND c.TIPO = 'RECUPERACAO'
        AND c.UTILIZADO = 0
        AND c.CONFIRMADO = 0
    """, (
        email,
        codigo
    ))

    resultado = cursor.fetchone()

    if not resultado:
        con.close()
        return False

    id_codigo = resultado[0]

    cursor.execute("""
        UPDATE CODIGOS
        SET CONFIRMADO = 1
        WHERE ID_CODIGO = ?
    """, (
        id_codigo,
    ))

    con.commit()
    con.close()

    return True


# =========================================================
# VERIFICAR SE RECUPERACAO FOI CONFIRMADA
# =========================================================

def recuperacao_confirmada(id_usuario):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT ID_CODIGO
        FROM CODIGOS
        WHERE ID_USUARIO = ?
        AND TIPO = 'RECUPERACAO'
        AND CONFIRMADO = 1
        AND UTILIZADO = 0
    """, (
        id_usuario,
    ))

    resultado = cursor.fetchone()

    con.close()

    return resultado is not None


# =========================================================
# VERIFICAR SENHA ATUAL
# =========================================================

def senha_ja_usada(id_usuario, nova_senha):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT SENHA
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    linhas = cursor.fetchall()

    cursor.execute("""
        SELECT SENHA
        FROM SENHAS_HISTORICO
        WHERE ID_USUARIO = ?
        ORDER BY DATA_ALTERACAO DESC
        ROWS 2
    """, (id_usuario,))

    linhas += cursor.fetchall()
    con.close()

    for linha in linhas:
        if check_password_hash(linha[0], nova_senha):
            return True

    return False


# =========================================================
# ALTERAR SENHA
# =========================================================

def alterar_senha_recuperacao(id_usuario, senha_hash):
    con = conectar()
    cursor = con.cursor()

    cursor.execute("""
        SELECT SENHA
        FROM USUARIOS
        WHERE ID_USUARIO = ?
    """, (id_usuario,))

    senha_antiga = cursor.fetchone()

    if senha_antiga:
        cursor.execute("""
            INSERT INTO SENHAS_HISTORICO (ID_USUARIO, SENHA)
            VALUES (?, ?)
        """, (id_usuario, senha_antiga[0]))

    cursor.execute("""
        UPDATE USUARIOS
        SET
            SENHA = ?,
            TENTATIVAS_LOGIN = 0,
            BLOQUEADO = 0
        WHERE ID_USUARIO = ?
    """, (
        senha_hash,
        id_usuario
    ))

    cursor.execute("""
        UPDATE CODIGOS
        SET UTILIZADO = 1
        WHERE ID_USUARIO = ?
        AND TIPO = 'RECUPERACAO'
        AND CONFIRMADO = 1
        AND UTILIZADO = 0
    """, (
        id_usuario,
    ))

    con.commit()
    con.close()

    return True