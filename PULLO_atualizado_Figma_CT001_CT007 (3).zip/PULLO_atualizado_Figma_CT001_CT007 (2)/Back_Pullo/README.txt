PULLO - versao completa

FUNCIONALIDADES:
1. Cadastro de Cliente e Entregador.
2. Envio real do codigo de confirmacao por email.
3. Confirmacao de cadastro com codigo.
4. Login para Cliente, Entregador e ADM.
5. Bloqueio apos 3 tentativas de senha errada.
6. Bloqueio de email duplicado.
7. Recuperacao de senha com envio real de codigo por email.
8. Nova senha com confirmacao.
9. Nova senha nao pode repetir as 3 ultimas senhas usadas.

COMO RODAR:
Backend:
- Entre em Back_Pullo
- pip install -r requirements.txt
- python app.py

Frontend:
- Entre em PULLO_linkado
- npm install
- npm run dev

OBSERVACAO:
O envio de email usa SMTP do Gmail configurado no backend.
