FIREBIRD_DSN = r"C:\Users\Aluno\Downloads\PULLO_atualizado_Figma_CT001_CT007 (2)\Back_Pullo\BANCO.FDB"
FIREBIRD_USER = "SYSDBA"
FIREBIRD_PASSWORD = "sysdba"

SECRET_KEY = "PULLO"

MAX_TENTATIVAS_LOGIN = 3
QUANTIDADE_SENHAS_BLOQUEADAS = 3

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

SMTP_EMAIL = "oliveirarodriguesotavio3@gmail.com"
SMTP_SENHA = "vmiwujvhfhdykapg"