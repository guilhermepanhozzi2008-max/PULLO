from flask import Flask, request, jsonify
from flask_cors import CORS
import fdb

app = Flask(__name__)
CORS(app)

# =========================
# CONEXÃO COM O BANCO
# =========================

def conectar():
    return fdb.connect(
        host='localhost',
        database='C:Users\Aluno\Desktop\Pullo\Back_Pullo\BANCO.FDB',
        user='SYSDBA',
        password='masterkey'
    )


# =========================
# USUÁRIOS
# =========================

@app.route('/usuarios', methods=['GET'])
def listar_usuarios():
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT ID_USUARIO, NOME, EMAIL, TELEFONE, TIPO
        FROM USUARIOS
    """)

    usuarios = []

    for u in cur.fetchall():
        usuarios.append({
            'id': u[0],
            'nome': u[1],
            'email': u[2],
            'telefone': u[3],
            'tipo': u[4]
        })

    con.close()

    return jsonify(usuarios)


@app.route('/usuarios', methods=['POST'])
def criar_usuario():
    dados = request.json

    nome = dados.get('nome')
    email = dados.get('email')
    senha = dados.get('senha')
    telefone = dados.get('telefone')
    tipo = dados.get('tipo')

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO USUARIOS
        (NOME, EMAIL, SENHA, TELEFONE, TIPO)
        VALUES (?, ?, ?, ?, ?)
    """, (nome, email, senha, telefone, tipo))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Usuário criado com sucesso'})


# =========================
# LOGIN
# =========================

@app.route('/login', methods=['POST'])
def login():
    dados = request.json

    email = dados.get('email')
    senha = dados.get('senha')

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT ID_USUARIO, NOME, EMAIL, TIPO
        FROM USUARIOS
        WHERE EMAIL = ? AND SENHA = ?
    """, (email, senha))

    usuario = cur.fetchone()

    con.close()

    if usuario:
        return jsonify({
            'mensagem': 'Login realizado',
            'id': usuario[0],
            'nome': usuario[1],
            'email': usuario[2],
            'tipo': usuario[3]
        })

    return jsonify({'erro': 'Email ou senha incorretos'}), 401


# =========================
# SUPERMERCADOS
# =========================

@app.route('/supermercados', methods=['GET'])
def listar_supermercados():
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT ID_SUPERMERCADO, NOME, TELEFONE, EMAIL, RUA
        FROM SUPERMERCADOS
    """)

    supermercados = []

    for s in cur.fetchall():
        supermercados.append({
            'id': s[0],
            'nome': s[1],
            'telefone': s[2],
            'email': s[3],
            'rua': s[4]
        })

    con.close()

    return jsonify(supermercados)


@app.route('/supermercados', methods=['POST'])
def criar_supermercado():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO SUPERMERCADOS
        (NOME, TELEFONE, EMAIL, RUA)
        VALUES (?, ?, ?, ?)
    """, (
        dados.get('nome'),
        dados.get('telefone'),
        dados.get('email'),
        dados.get('rua')
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Supermercado cadastrado'})


# =========================
# ENDEREÇOS
# =========================

@app.route('/enderecos', methods=['POST'])
def criar_endereco():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO ENDERECOS
        (ID_USUARIO, RUA, NUMERO, BAIRRO, CIDADE, CEP)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        dados.get('id_usuario'),
        dados.get('rua'),
        dados.get('numero'),
        dados.get('bairro'),
        dados.get('cidade'),
        dados.get('cep')
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Endereço cadastrado'})


# =========================
# PEDIDOS
# =========================

@app.route('/pedidos', methods=['GET'])
def listar_pedidos():
    con = conectar()
    cur = con.cursor()

    cur.execute("""
        SELECT ID_PEDIDO, ID_CLIENTE, ID_SUPERMERCADO,
               ENDERECO, HORARIO, STATUS
        FROM PEDIDOS
    """)

    pedidos = []

    for p in cur.fetchall():
        pedidos.append({
            'id': p[0],
            'id_cliente': p[1],
            'id_supermercado': p[2],
            'endereco': p[3],
            'horario': p[4],
            'status': p[5]
        })

    con.close()

    return jsonify(pedidos)


@app.route('/pedidos', methods=['POST'])
def criar_pedido():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO PEDIDOS
        (ID_CLIENTE, ID_SUPERMERCADO, ENDERECO, HORARIO, STATUS)
        VALUES (?, ?, ?, ?, ?)
    """, (
        dados.get('id_cliente'),
        dados.get('id_supermercado'),
        dados.get('endereco'),
        dados.get('horario'),
        'Pendente'
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Pedido criado'})


# =========================
# ITENS DO PEDIDO
# =========================

@app.route('/itens', methods=['POST'])
def criar_item():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO ITENS_PEDIDO
        (ID_PEDIDO, PRODUTO, QUANTIDADE)
        VALUES (?, ?, ?)
    """, (
        dados.get('id_pedido'),
        dados.get('produto'),
        dados.get('quantidade')
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Item adicionado ao pedido'})


# =========================
# ENTREGAS
# =========================

@app.route('/entregas', methods=['POST'])
def criar_entrega():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO ENTREGAS
        (ID_PEDIDO, ID_ENTREGADOR, STATUS)
        VALUES (?, ?, ?)
    """, (
        dados.get('id_pedido'),
        dados.get('id_entregador'),
        'Pendente'
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Entrega criada'})


# =========================
# ATUALIZAR STATUS DA ENTREGA
# =========================

@app.route('/entregas/<int:id>', methods=['PUT'])
def atualizar_entrega(id):
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        UPDATE ENTREGAS
        SET STATUS = ?
        WHERE ID_ENTREGA = ?
    """, (
        dados.get('status'),
        id
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Status atualizado'})


# =========================
# AVALIAÇÕES
# =========================

@app.route('/avaliacoes', methods=['POST'])
def criar_avaliacao():
    dados = request.json

    con = conectar()
    cur = con.cursor()

    cur.execute("""
        INSERT INTO AVALIACOES
        (ID_PEDIDO, NOTA, COMENTARIO)
        VALUES (?, ?, ?)
    """, (
        dados.get('id_pedido'),
        dados.get('nota'),
        dados.get('comentario')
    ))

    con.commit()
    con.close()

    return jsonify({'mensagem': 'Avaliação criada'})


# =========================
# INICIAR SERVIDOR
# =========================

if __name__ == '__main__':
    app.run(debug=True)