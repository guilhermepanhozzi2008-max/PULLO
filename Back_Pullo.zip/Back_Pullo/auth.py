from flask import Blueprint, jsonify, request, session

from models import user_store

auth_bp = Blueprint("auth", __name__, url_prefix="/api")


def user_response(user):
    return {
        "id": user.id,
        "name": user.name,
        "email": user.email,
    }


@auth_bp.route("/register", methods=["POST"])
@auth_bp.route("/cadastro", methods=["POST"])
def register_user():
    payload = request.get_json(silent=True) or {}

    name = payload.get("name") or payload.get("nome")
    email = payload.get("email")
    password = payload.get("password") or payload.get("senha")

    if not name or not email or not password:
        return jsonify({"message": "Nome, e-mail e senha são obrigatórios."}), 400

    try:
        user = user_store.create_user(name, email, password)
    except ValueError as exc:
        return jsonify({"message": str(exc)}), 400

    session.clear()
    session["user_id"] = user.id

    return jsonify({
        "message": "Usuário cadastrado com sucesso.",
        "user": user_response(user),
    }), 201


@auth_bp.route("/login", methods=["POST"])
def login_user():
    payload = request.get_json(silent=True) or {}

    email = payload.get("email")
    password = payload.get("password") or payload.get("senha")

    if not email or not password:
        return jsonify({"message": "E-mail e senha são obrigatórios."}), 400

    user = user_store.authenticate(email, password)

    if not user:
        return jsonify({"message": "Credenciais inválidas."}), 401

    session.clear()
    session["user_id"] = user.id

    return jsonify({
        "message": "Login realizado com sucesso.",
        "user": user_response(user),
    })


@auth_bp.route("/logout", methods=["POST"])
def logout_user():
    session.clear()
    return jsonify({"message": "Logout realizado com sucesso."})


@auth_bp.route("/me", methods=["GET"])
def current_user():
    user_id = session.get("user_id")

    if not user_id:
        return jsonify({"message": "Usuário não autenticado."}), 401

    user = user_store.get_user_by_id(user_id)
    if not user:
        session.clear()
        return jsonify({"message": "Usuário não encontrado."}), 401

    return jsonify(user_response(user))
