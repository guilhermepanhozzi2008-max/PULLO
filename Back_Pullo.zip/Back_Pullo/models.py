import sqlite3
from dataclasses import dataclass
from typing import Optional

from werkzeug.security import check_password_hash, generate_password_hash

from config import get_db


@dataclass(frozen=True)
class User:
    id: int
    name: str
    email: str
    password_hash: str

    @classmethod
    def from_row(cls, row):
        return cls(
            id=row["id"],
            name=row["name"],
            email=row["email"],
            password_hash=row["password_hash"],
        )


class UserStore:
    def create_user(self, name: str, email: str, password: str) -> User:
        name = name.strip()
        email = email.strip().lower()

        if not name:
            raise ValueError("O nome é obrigatório.")

        if not email:
            raise ValueError("O e-mail é obrigatório.")

        if "@" not in email or "." not in email:
            raise ValueError("Informe um e-mail válido.")

        if not password or len(password) < 6:
            raise ValueError("A senha deve conter no mínimo 6 caracteres.")

        password_hash = generate_password_hash(password)
        db = get_db()

        try:
            cursor = db.execute(
                """
                INSERT INTO users (name, email, password_hash)
                VALUES (?, ?, ?)
                """,
                (name, email, password_hash),
            )
            db.commit()
        except sqlite3.IntegrityError as exc:
            raise ValueError("Este e-mail já está cadastrado.") from exc

        return self.get_user_by_id(cursor.lastrowid)

    def authenticate(self, email: str, password: str) -> Optional[User]:
        user = self.get_user_by_email(email)

        if user and check_password_hash(user.password_hash, password):
            return user

        return None

    def get_user_by_email(self, email: str) -> Optional[User]:
        row = get_db().execute(
            """
            SELECT id, name, email, password_hash
            FROM users
            WHERE email = ?
            """,
            (email.strip().lower(),),
        ).fetchone()

        return User.from_row(row) if row else None

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        row = get_db().execute(
            """
            SELECT id, name, email, password_hash
            FROM users
            WHERE id = ?
            """,
            (user_id,),
        ).fetchone()

        return User.from_row(row) if row else None

    def clear_all(self):
        db = get_db()
        db.execute("DELETE FROM users")
        db.execute("DELETE FROM sqlite_sequence WHERE name = 'users'")
        db.commit()


user_store = UserStore()
