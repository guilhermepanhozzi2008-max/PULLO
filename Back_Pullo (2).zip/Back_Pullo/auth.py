import secrets
import smtplib

from email.mime.text import MIMEText

from flask import Flask, Blueprint, jsonify, request
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

import config
import models


app = Flask(__name__)

auth_bp = Blueprint(
    "auth",
    __name__,
    url_prefix="/api"
)

CORS(app)


# =========================================================
# VALIDACOES
# =========================================================

def email_valido(email):
    return "@" in email and "." in email


def senha_valida(senha):
    return len(senha) >= 6


# =========================================================
# EMAIL
# =========================================================

def enviar_email(destinatario, assunto, corpo):

    mensagem = MIMEText(
        corpo,
        "plain",
        "utf-8"
    )

    mensagem["Subject"] = assunto
    mensagem["From"] = config.SMTP_EMAIL
    mensagem["To"] = destinatario

    with smtplib.SMTP(
        config.SMTP_HOST,
        config.SMTP_PORT
    ) as servidor:

        servidor.starttls()

        servidor.login(
            config.SMTP_EMAIL,
            config.SMTP_SENHA.replace(" ", "")
        )

        servidor.sendmail(
            config.SMTP_EMAIL,
            [destinatario],
            mensagem.as_string()
        )


# =========================================================
# CADASTRO
# =========================================================

@auth_bp.route("/cadastro", methods=["POST"])
def cadastro():

    try:

        data = request.get_json(silent=True) or {}

        nome = data.get("nome")
        email = data.get("email")
        telefone = data.get("telefone")
        senha = data.get("senha")
        tipo = data.get("tipo")

        # campos obrigatorios
        if not nome or not email or not senha or not tipo:
            return jsonify({
                "error": "Nome, email, senha e tipo sao obrigatorios"
            }), 400

        # tipo do usuario
        if tipo not in ["CLIENTE", "ENTREGADOR"]:
            return jsonify({
                "error": "Tipo de usuario invalido"
            }), 400

        # email
        if not email_valido(email):
            return jsonify({
                "error": "Email invalido"
            }), 400

        # senha
        if not senha_valida(senha):
            return jsonify({
                "error": "Senha deve ter no minimo 6 caracteres"
            }), 400

        # procura usuario
        usuario_existente = models.buscar_usuario_por_email(email)

        # =====================================================
        # EMAIL JA EXISTE
        # =====================================================

        if usuario_existente:

            id_usuario = usuario_existente[0]
            confirmado = usuario_existente[7]

            # se ja confirmou, nao pode cadastrar novamente
            if confirmado:
                return jsonify({
                    "error": "Email ja cadastrado"
                }), 400

            # usuario existe, mas ainda nao confirmou
            codigo = f"{secrets.randbelow(1000000):06d}"

            models.criar_codigo(
                id_usuario,
                codigo,
                "CONFIRMACAO"
            )

            enviar_email(
                email,
                "Confirmacao de cadastro",
                f"Seu codigo de confirmacao e: {codigo}"
            )

            return jsonify({
                "message": "Cadastro pendente. Novo codigo enviado.",
                "precisa_confirmar": True
            }), 200

        # =====================================================
        # NOVO USUARIO
        # =====================================================

        senha_hash = generate_password_hash(senha)

        id_usuario = models.criar_usuario(
            nome,
            email,
            senha_hash,
            telefone,
            tipo
        )

        codigo = f"{secrets.randbelow(1000000):06d}"

        models.criar_codigo(
            id_usuario,
            codigo,
            "CONFIRMACAO"
        )

        enviar_email(
            email,
            "Confirmacao de cadastro",
            f"Seu codigo de confirmacao e: {codigo}"
        )

        return jsonify({
            "message": "Usuario cadastrado com sucesso",
            "precisa_confirmar": True
        }), 201

    except Exception as e:

        print("ERRO NO CADASTRO:", str(e))

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CADASTRO
# =========================================================

@auth_bp.route("/verificar_codigo", methods=["POST"])
def verificar_codigo():

    try:

        data = request.get_json(silent=True) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:
            return jsonify({
                "error": "Email e codigo sao obrigatorios"
            }), 400

        confirmado = models.confirmar_codigo(
            email,
            codigo
        )

        if not confirmado:
            return jsonify({
                "error": "Codigo invalido"
            }), 401

        return jsonify({
            "message": "Cadastro confirmado com sucesso"
        }), 200

    except Exception as e:

        print("ERRO AO CONFIRMAR CADASTRO:", str(e))

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# LOGIN
# =========================================================

@auth_bp.route("/login", methods=["POST"])
def login():

    try:

        data = request.get_json(silent=True) or {}

        email = data.get("email")
        senha = data.get("senha")

        if not email or not senha:
            return jsonify({
                "error": "Email e senha sao obrigatorios"
            }), 400

        usuario = models.buscar_usuario_por_email(email)

        if not usuario:
            return jsonify({
                "error": "Email ou senha incorretos"
            }), 401

        (
            id_usuario,
            nome,
            email_db,
            senha_hash,
            tipo,
            tentativas,
            bloqueado,
            confirmado
        ) = usuario

        # bloqueado
        if bloqueado:
            return jsonify({
                "error": "Usuario bloqueado por excesso de tentativas"
            }), 403

        # precisa confirmar cadastro
        if not confirmado:
            return jsonify({
                "error": "Confirme seu cadastro antes de fazer login",
                "precisa_confirmar": True
            }), 403

        # senha incorreta
        if not check_password_hash(
            senha_hash,
            senha
        ):

            models.registrar_tentativa_errada(
                id_usuario,
                tentativas
            )

            tentativas_restantes = (
                config.MAX_TENTATIVAS_LOGIN
                - (tentativas + 1)
            )

            if tentativas_restantes <= 0:

                return jsonify({
                    "error": "Usuario bloqueado por excesso de tentativas"
                }), 403

            return jsonify({
                "error": "Email ou senha incorretos",
                "tentativas_restantes": tentativas_restantes
            }), 401

        # login correto
        models.zerar_tentativas(id_usuario)

        return jsonify({
            "message": "Login realizado com sucesso",
            "usuario": {
                "id": id_usuario,
                "nome": nome,
                "email": email_db,
                "tipo": tipo
            }
        }), 200

    except Exception as e:

        print("ERRO NO LOGIN:", str(e))

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# ESQUECEU SENHA
# =========================================================

@auth_bp.route("/esqueceu_senha", methods=["POST"])
def esqueceu_senha():

    try:

        data = request.get_json(silent=True) or {}

        email = data.get("email")

        if not email:
            return jsonify({
                "error": "Email e obrigatorio"
            }), 400

        usuario = models.buscar_usuario_por_email(email)

        if not usuario:
            return jsonify({
                "error": "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        codigo = f"{secrets.randbelow(1000000):06d}"

        models.criar_codigo(
            id_usuario,
            codigo,
            "RECUPERACAO"
        )

        enviar_email(
            email,
            "Recuperacao de senha",
            f"Seu codigo de recuperacao e: {codigo}"
        )

        return jsonify({
            "message": "Codigo de recuperacao enviado"
        }), 200

    except Exception as e:

        print("ERRO NA RECUPERACAO:", str(e))

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# CONFIRMAR CODIGO DE RECUPERACAO
# =========================================================

@auth_bp.route(
    "/confirmar_codigo_recuperacao",
    methods=["POST"]
)
def confirmar_codigo_recuperacao():

    try:

        data = request.get_json(silent=True) or {}

        email = data.get("email")
        codigo = data.get("codigo")

        if not email or not codigo:
            return jsonify({
                "error": "Email e codigo sao obrigatorios"
            }), 400

        resultado = models.confirmar_codigo_recuperacao(
            email,
            codigo
        )

        if not resultado:
            return jsonify({
                "error": "Codigo de recuperacao invalido"
            }), 401

        return jsonify({
            "message": "Codigo confirmado com sucesso",
            "pode_alterar_senha": True
        }), 200

    except Exception as e:

        print(
            "ERRO AO CONFIRMAR CODIGO DE RECUPERACAO:",
            str(e)
        )

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# ALTERAR SENHA
# =========================================================

@auth_bp.route("/alterar_senha", methods=["POST"])
def alterar_senha():

    try:

        data = request.get_json(silent=True) or {}

        email = data.get("email")
        nova_senha = data.get("nova_senha")
        confirmar_senha = data.get("confirmar_senha")

        if (
            not email
            or not nova_senha
            or not confirmar_senha
        ):
            return jsonify({
                "error": "Todos os campos sao obrigatorios"
            }), 400

        # senhas diferentes
        if nova_senha != confirmar_senha:
            return jsonify({
                "error": "As senhas nao conferem"
            }), 400

        # tamanho minimo
        if not senha_valida(nova_senha):
            return jsonify({
                "error": "Senha deve ter no minimo 6 caracteres"
            }), 400

        usuario = models.buscar_usuario_por_email(email)

        if not usuario:
            return jsonify({
                "error": "Usuario nao encontrado"
            }), 404

        id_usuario = usuario[0]

        # verifica se o codigo foi confirmado
        if not models.recuperacao_confirmada(
            id_usuario
        ):
            return jsonify({
                "error": "Confirme o codigo de recuperacao primeiro"
            }), 403

        # nao deixa usar a senha atual
        if models.senha_ja_usada(
            id_usuario,
            nova_senha
        ):
            return jsonify({
                "error": "A nova senha nao pode ser igual a senha atual"
            }), 400

        senha_hash = generate_password_hash(
            nova_senha
        )

        models.alterar_senha_recuperacao(
            id_usuario,
            senha_hash
        )

        return jsonify({
            "message": "Senha alterada com sucesso"
        }), 200

    except Exception as e:

        print("ERRO AO ALTERAR SENHA:", str(e))

        return jsonify({
            "error": str(e)
        }), 500


# =========================================================
# REGISTRAR BLUEPRINT
# =========================================================

app.register_blueprint(auth_bp)


# =========================================================
# INICIAR SERVIDOR
# =========================================================

if __name__ == "__main__":
    app.run(
        debug=True,
        port=5000
    )