import os

FIREBIRD_DSN = r"localhost:C:\Users\Aluno\Desktop\Pullo\Back_Pullo\BANCO.FDB"
FIREBIRD_USER = "SYSDBA"
FIREBIRD_PASSWORD = "sysdba"

SECRET_KEY = "PULLO"

SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587

SMTP_EMAIL = "oliveirarodriguesotavio3@gmail.com"
SMTP_SENHA = "vmiwujvhfhdykapg"

QUANTIDADE_SENHAS_BLOQUEADAS = 3
MAX_TENTATIVAS_LOGIN = 3