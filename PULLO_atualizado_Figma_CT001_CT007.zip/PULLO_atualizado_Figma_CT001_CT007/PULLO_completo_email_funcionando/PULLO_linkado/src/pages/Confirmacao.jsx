import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./Confirmacao.module.css";

export default function Confirmacao() {

    const navigate = useNavigate();

    const [codigo, setCodigo] = useState("");

    const email = localStorage.getItem(
        "email_cadastro"
    );

    async function confirmar(e) {

        e.preventDefault();

        if (!email) {

            alert(
                "E-mail não encontrado. Faça o cadastro novamente."
            );

            navigate("/cadastro");

            return;
        }

        if (!codigo) {

            alert(
                "Digite o código recebido no e-mail."
            );

            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/verificar_codigo",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        codigo: codigo
                    })
                }
            );

            const dados = await resposta.json();

            console.log("Código:", codigo);
            console.log("Resposta:", dados);
            console.log("Status:", resposta.status);

            if (resposta.ok) {

                localStorage.removeItem(
                    "email_cadastro"
                );

                alert(
                    "Conta confirmada com sucesso!"
                );

                navigate(
                    "/login",
                    {
                        replace: true
                    }
                );

                return;
            }

            alert(
                dados.error ||
                "Código inválido."
            );

        } catch (erro) {

            console.log(
                "Erro ao confirmar:",
                erro
            );

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Confirmar conta">

            <p className={styles.texto}>

                Enviamos um código de confirmação para:

                <br />

                <strong>
                    {email || "seu e-mail"}
                </strong>

            </p>

            <form
                className={styles.formulario}
                onSubmit={confirmar}
            >

                <Input
                    placeholder="Código recebido por e-mail"
                    value={codigo}
                    onChange={(e) =>
                        setCodigo(e.target.value)
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Confirmar
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/cadastro")
                }
            >
                Voltar
            </Button>

        </AuthBox>
    );
}