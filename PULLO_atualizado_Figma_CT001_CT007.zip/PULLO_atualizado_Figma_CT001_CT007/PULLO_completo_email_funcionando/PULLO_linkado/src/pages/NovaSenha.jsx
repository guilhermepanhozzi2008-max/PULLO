import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./NovaSenha.module.css";

export default function NovaSenha() {

    const navigate = useNavigate();

    const [novaSenha, setNovaSenha] =
        useState("");

    const [confirmar, setConfirmar] =
        useState("");

    const email =
        localStorage.getItem(
            "email_recuperacao"
        );

    async function alterarSenha(e) {

        e.preventDefault();

        if (!novaSenha || !confirmar) {

            alert(
                "Preencha todos os campos."
            );

            return;
        }

        if (novaSenha !== confirmar) {

            alert(
                "As senhas não são iguais."
            );

            return;
        }

        try {

            const resposta = await fetch(
                "http://localhost:5000/api/alterar_senha",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        nova_senha: novaSenha,
                        confirmar_senha: confirmar
                    })
                }
            );

            const dados =
                await resposta.json();

            if (!resposta.ok) {

                alert(
                    dados.error ||
                    "Erro ao alterar senha."
                );

                return;
            }

            alert(
                "Senha alterada com sucesso!"
            );

            localStorage.removeItem(
                "email_recuperacao"
            );

            navigate("/login");

        } catch (erro) {

            console.log(
                "Erro:",
                erro
            );

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Nova senha">

            <form
                className={styles.formulario}
                onSubmit={alterarSenha}
            >

                <Input
                    type="password"
                    placeholder="Nova senha"
                    value={novaSenha}
                    onChange={(e) =>
                        setNovaSenha(
                            e.target.value
                        )
                    }
                />

                <Input
                    type="password"
                    placeholder="Confirmar nova senha"
                    value={confirmar}
                    onChange={(e) =>
                        setConfirmar(
                            e.target.value
                        )
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Alterar senha
                </Button>

            </form>

        </AuthBox>
    );
}