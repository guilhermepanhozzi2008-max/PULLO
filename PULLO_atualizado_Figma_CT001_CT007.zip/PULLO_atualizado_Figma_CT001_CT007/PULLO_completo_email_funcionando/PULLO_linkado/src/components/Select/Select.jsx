import styles from "./Select.module.css";

export default function Select({ value, onChange, children }) {

    return (
        <select
            value={value}
            onChange={onChange}
            className={styles.campo}
        >
            {children}
        </select>
    );
}
