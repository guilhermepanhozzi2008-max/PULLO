import styles from "./Input.module.css";

export default function Input({
    type = "text",
    placeholder,
    value,
    defaultValue,
    onChange,
    name,
}) {

    return (
        <input
            type={type}
            name={name}
            placeholder={placeholder}
            value={value}
            defaultValue={defaultValue}
            onChange={onChange}
            className={styles.campo}
        />
    );
}
