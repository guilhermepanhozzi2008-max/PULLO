import styles from "./Button.module.css";

export default function Button({
                                   children,
                                   type = "button",
                                   onClick,
                                   fullWidth = false,
                                   variant = "primary",
                                   disabled = false
                               }) {
    return (
        <button
            type={type}
            onClick={onClick}
            disabled={disabled}
            className={`
                ${styles.button}
                ${styles[variant] || ""}
                ${fullWidth ? styles.fullWidth : ""}
            `}
        >
            {children}
        </button>
    );
}