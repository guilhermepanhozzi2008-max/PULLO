PULLO - versão para testes sem envio de email

ALTERAÇÕES:
1. O backend NÃO envia mais email.
2. O código de confirmação de cadastro é retornado pela API em "codigo_teste".
3. O código de recuperação também é retornado em "codigo_teste".
4. A tela de confirmação mostra o código para facilitar o teste CT005/CT006.
5. A recuperação de senha foi corrigida para usar:
   POST /api/confirmar_codigo_recuperacao
   POST /api/alterar_senha
6. Foi criada a tabela SENHAS_HISTORICO no BANCO.FDB.
7. A nova senha não pode ser igual à senha atual nem às 3 últimas senhas armazenadas.
8. O caminho do BANCO.FDB agora é relativo à pasta do backend.
9. Foi adicionado testes_auth.py com os testes CT001 a CT007.

COMO RODAR:
Backend:
- Entre na pasta Back_Pullo
- Ative seu ambiente Python
- Execute: python app.py

Frontend:
- Entre na pasta PULLO_linkado
- Execute: npm install
- Execute: npm run dev

IMPORTANTE:
Os códigos aparecem na tela/API somente porque o email foi desativado para os testes.
