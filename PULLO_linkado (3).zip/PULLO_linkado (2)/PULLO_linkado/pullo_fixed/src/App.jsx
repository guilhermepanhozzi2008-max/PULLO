import { useState } from "react";

import {
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import Login from "./pages/Login";
import Cadastro from "./pages/Cadastro";
import Confirmacao from "./pages/Confirmacao";
import RecuperarSenha from "./pages/RecuperarSenha";

import Cliente from "./pages/Cliente";
import Entregador from "./pages/Entregador";
import Admin from "./pages/Admin";


function RotaProtegida({
                           usuario,
                           tipo,
                           children
                       }) {
    if (!usuario) {
        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    if (usuario.tipo !== tipo) {
        return (
            <Navigate
                to="/login"
                replace
            />
        );
    }

    return children;
}


export default function App() {
    const [usuario, setUsuario] =
        useState(null);

    function sair() {
        setUsuario(null);
    }

    return (
        <Routes>

            <Route
                path="/login"
                element={
                    <Login
                        entrar={setUsuario}
                    />
                }
            />

            <Route
                path="/cadastro"
                element={<Cadastro />}
            />

            <Route
                path="/confirmacao"
                element={<Confirmacao />}
            />

            <Route
                path="/recuperar-senha"
                element={<RecuperarSenha />}
            />

            <Route
                path="/cliente"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="CLIENTE"
                    >
                        <Cliente
                            usuario={usuario}
                            sair={sair}
                        />
                    </RotaProtegida>
                }
            />

            <Route
                path="/entregador"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="ENTREGADOR"
                    >
                        <Entregador
                            usuario={usuario}
                            sair={sair}
                        />
                    </RotaProtegida>
                }
            />

            <Route
                path="/admin"
                element={
                    <RotaProtegida
                        usuario={usuario}
                        tipo="ADM"
                    >
                        <Admin
                            usuario={usuario}
                            sair={sair}
                        />
                    </RotaProtegida>
                }
            />

            <Route
                path="/"
                element={
                    <Navigate
                        to="/login"
                        replace
                    />
                }
            />

            <Route
                path="*"
                element={
                    <Navigate
                        to="/login"
                        replace
                    />
                }
            />

        </Routes>
    );
}