import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";
import styles from "./RecuperarSenha.module.css";

export default function RecuperarSenha() {
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [codigo, setCodigo] = useState("");
    const [novaSenha, setNovaSenha] = useState("");
    const [confirmar, setConfirmar] = useState("");
    const [etapa, setEtapa] = useState(1);

    async function continuar(e) {
        e.preventDefault();

        if (!email) {
            alert("Digite seu e-mail.");
            return;
        }

        try {
            const resposta = await fetch("http://localhost:5000/api/esqueceu_senha", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({ email })
            });

            const dados = await resposta.json();

            if (!resposta.ok) {
                throw new Error(dados.error || "Erro ao solicitar recuperação.");
            }

            alert("Código de recuperação enviado para o e-mail.");
            setEtapa(2);

        } catch (erro) {
            alert(erro.message || "Erro ao conectar com o servidor.");
        }
    }

    async function alterarSenha(e) {
        e.preventDefault();

        if (!codigo || !novaSenha || !confirmar) {
            alert("Preencha todos os campos.");
            return;
        }

        if (novaSenha !== confirmar) {
            alert("As senhas não são iguais.");
            return;
        }

        try {
            const resposta = await fetch("http://localhost:5000/api/redefinir_senha", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                credentials: "include",
                body: JSON.stringify({
                    email,
                    codigo,
                    nova_senha: novaSenha,
                    confirmar_senha: confirmar
                })
            });

            const dados = await resposta.json();

            if (!resposta.ok) {
                throw new Error(dados.error || "Erro ao alterar a senha.");
            }

            alert("Senha alterada com sucesso.");
            navigate("/login");

        } catch (erro) {
            alert(erro.message || "Erro ao conectar com o servidor.");
        }
    }

    return (
        <AuthBox titulo="Recuperar senha">
            {etapa === 1 && (
                <form className={styles.formulario} onSubmit={continuar}>
                    <Input type="email" placeholder="Digite seu e-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
                    <Button type="submit" fullWidth>Continuar</Button>
                </form>
            )}

            {etapa === 2 && (
                <form className={styles.formulario} onSubmit={alterarSenha}>
                    <Input placeholder="Código recebido por e-mail" value={codigo} onChange={(e) => setCodigo(e.target.value)} />
                    <Input type="password" placeholder="Nova senha" value={novaSenha} onChange={(e) => setNovaSenha(e.target.value)} />
                    <Input type="password" placeholder="Confirmar nova senha" value={confirmar} onChange={(e) => setConfirmar(e.target.value)} />
                    <Button type="submit" fullWidth>Alterar senha</Button>
                </form>
            )}

            <Button variant="link" fullWidth onClick={() => navigate("/login")}>Voltar</Button>
        </AuthBox>
    );
}