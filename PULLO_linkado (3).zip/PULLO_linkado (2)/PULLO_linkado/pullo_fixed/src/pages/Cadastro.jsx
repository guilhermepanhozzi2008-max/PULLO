import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Select from "../components/Select/Select";
import Button from "../components/Button/Button";

import styles from "./Cadastro.module.css";

export default function Cadastro() {
    const navigate = useNavigate();

    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [telefone, setTelefone] = useState("");
    const [senha, setSenha] = useState("");
    const [tipo, setTipo] = useState("CLIENTE");

    async function cadastrar(e) {
        e.preventDefault();

        if (!nome || !email || !senha || !tipo) {
            alert("Preencha todos os campos obrigatórios.");
            return;
        }

        try {
            const resposta = await fetch(
                "http://localhost:5000/api/cadastro",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        nome,
                        email,
                        telefone,
                        senha,
                        tipo
                    })
                }
            );

            const dados = await resposta.json();

            if (!resposta.ok) {
                alert(
                    dados.error ||
                    "Erro ao realizar cadastro."
                );
                return;
            }

            // salva também no localStorage
            localStorage.setItem(
                "email_cadastro",
                email
            );

            // passa o email diretamente para a próxima página
            navigate("/confirmacao", {
                state: {
                    email: email
                }
            });

        } catch (erro) {
            console.log("Erro no cadastro:", erro);

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Criar conta">

            <form
                className={styles.formulario}
                onSubmit={cadastrar}
            >

                <Input
                    placeholder="Nome completo"
                    value={nome}
                    onChange={(e) =>
                        setNome(e.target.value)
                    }
                />

                <Input
                    type="email"
                    placeholder="E-mail"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                />

                <Input
                    placeholder="Telefone"
                    value={telefone}
                    onChange={(e) =>
                        setTelefone(e.target.value)
                    }
                />

                <Input
                    type="password"
                    placeholder="Senha"
                    value={senha}
                    onChange={(e) =>
                        setSenha(e.target.value)
                    }
                />

                <Select
                    value={tipo}
                    onChange={(e) =>
                        setTipo(e.target.value)
                    }
                >
                    <option value="CLIENTE">
                        Cliente
                    </option>

                    <option value="ENTREGADOR">
                        Entregador
                    </option>
                </Select>

                <Button
                    type="submit"
                    fullWidth
                    onClick={() =>
                        navigate("/Confirmacao", {})
                    }
                >
                    Finalizar cadastro
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/login")
                }
            >
                Voltar para login
            </Button>

        </AuthBox>
    );
}