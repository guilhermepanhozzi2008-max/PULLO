import { useState } from "react";
import {
    useLocation,
    useNavigate
} from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./Confirmacao.module.css";

export default function Confirmacao() {
    const navigate = useNavigate();
    const location = useLocation();

    const [codigo, setCodigo] = useState("");

    // tenta pegar primeiro pelo navigate
    const emailNavegacao =
        location.state?.email;

    // se não tiver, tenta pelo localStorage
    const emailSalvo =
        localStorage.getItem("email_cadastro");

    const email =
        emailNavegacao || emailSalvo;

    async function confirmar(e) {
        e.preventDefault();

        if (!email) {
            alert(
                "E-mail de cadastro não encontrado. Refaça o cadastro."
            );

            navigate("/cadastro");
            return;
        }

        if (!codigo) {
            alert(
                "Digite o código recebido no e-mail."
            );
            return;
        }

        try {
            const resposta = await fetch(
                "http://localhost:5000/api/verificar_codigo",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email: email,
                        codigo: codigo
                    })
                }
            );

            const dados = await resposta.json();

            if (!resposta.ok) {
                alert(
                    dados.error ||
                    "Código inválido."
                );
                return;
            }

            alert(
                "Conta confirmada com sucesso!"
            );

            localStorage.removeItem(
                "email_cadastro"
            );

            navigate("/login");

        } catch (erro) {
            console.log(
                "Erro ao confirmar:",
                erro
            );

            alert(
                "Erro ao conectar com o servidor."
            );
        }
    }

    return (
        <AuthBox titulo="Confirmar conta">

            <p className={styles.texto}>
                Digite o código enviado para:
                <br />
                <strong>
                    {email || "seu e-mail"}
                </strong>
            </p>

            <form
                className={styles.formulario}
                onSubmit={confirmar}
            >

                <Input
                    placeholder="Código de confirmação"
                    value={codigo}
                    onChange={(e) =>
                        setCodigo(e.target.value)
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Confirmar
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/cadastro")
                }
            >
                Voltar
            </Button>

        </AuthBox>
    );
}