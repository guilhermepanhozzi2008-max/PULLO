import { useState } from "react";
import { useNavigate } from "react-router-dom";

import AuthBox from "../components/AuthBox/AuthBox";
import Input from "../components/Input/Input";
import Button from "../components/Button/Button";

import styles from "./Login.module.css";

export default function Login({ entrar }) {
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");

    async function fazerLogin(e) {
        e.preventDefault();

        if (!email || !senha) {
            alert("Digite seu e-mail e senha.");
            return;
        }

        try {
            const resposta = await fetch(
                "http://localhost:5000/api/login",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        email,
                        senha
                    })
                }
            );

            const dados = await resposta.json();

            if (!resposta.ok) {
                alert(
                    dados.error ||
                    "Erro ao realizar login."
                );
                return;
            }

            const usuario = dados.usuario;

            entrar(usuario);

            if (usuario.tipo === "CLIENTE") {
                navigate("/cliente");
                return;
            }

            if (usuario.tipo === "ENTREGADOR") {
                navigate("/entregador");
                return;
            }

            if (usuario.tipo === "ADM") {
                navigate("/admin");
                return;
            }

            alert("Tipo de usuário inválido.");

        } catch (erro) {
            console.log(erro);

            alert("Erro ao conectar com o servidor.");
        }
    }

    return (
        <AuthBox titulo="Entrar">

            <form
                className={styles.formulario}
                onSubmit={fazerLogin}
            >

                <Input
                    type="email"
                    placeholder="E-mail"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                />

                <Input
                    type="password"
                    placeholder="Senha"
                    value={senha}
                    onChange={(e) =>
                        setSenha(e.target.value)
                    }
                />

                <Button
                    type="submit"
                    fullWidth
                >
                    Entrar
                </Button>

            </form>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/cadastro")
                }
            >
                Criar conta
            </Button>

            <Button
                variant="link"
                fullWidth
                onClick={() =>
                    navigate("/recuperar-senha")
                }
            >
                Esqueci minha senha
            </Button>

        </AuthBox>
    );
}