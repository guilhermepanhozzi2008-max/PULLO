import styles from "./AuthBox.module.css";

export default function AuthBox({ titulo, children }) {

    return (
        <main className={styles.tela}>

            <div className={styles.caixa}>

                <h1>{titulo}</h1>

                {children}

            </div>

        </main>
    );
}
